----
-- main module
-- @module merge

---- first fun
function one()
end
