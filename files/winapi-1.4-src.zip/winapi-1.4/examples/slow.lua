print(arg[1])
for i = 1,1e8 do end


