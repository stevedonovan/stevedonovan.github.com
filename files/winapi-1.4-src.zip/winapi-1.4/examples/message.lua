
local W = require 'winapi'


print(W.show_message("Message","stuff"))
print(W.show_message("Message","stuff\nand nonsense","yes-no","warning"))




