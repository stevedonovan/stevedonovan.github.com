These are instructive little programs that use llib.

To build them, use the makefile like so:

$ make PROG=name

where name is the program name without extension.
