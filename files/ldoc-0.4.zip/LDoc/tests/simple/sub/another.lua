-----------
-- Another module. Shows how module name inference works relative
-- to base

-------
-- First function.
function first()
end
