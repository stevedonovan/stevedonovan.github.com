------------
-- A little new-style module.
-- But with no explicit module name given.

--- return the answer.
function simple2.answer()
  return 42
end
