require 'pl'
relpath = path.relpath

print(relpath [[d:\dev\lua\Penlight\tests\one.lua]])
print(relpath [[d:\dev\lua\Penlight\tests\dodo\one.lua]])

print(relpath [[d:\dev\lua\Penlight\readme.md]])
