<children>
  <child>
    <name>alice</name>
    <age>5</age>
    <toy type='fluffy'/>
  </child>
  <child>
    <name>bob</name>
    <age>6</age>
    <toy type='squeaky'/>
  </child>
</children>

