------------
-- Classic Lua 5.1 module,
-- Description here
----

module 'two'

--- answer to everything.
function answer ()
    return 42
end


