-----------
-- Extra module
-- @submodule mylib

--- will appear in mylib's docs!
function E ()

end

--- ditto
function F ()

end
