--- simplified LDoc style
module 'easy'

--- First one.
-- string: name
-- int: age
function first(name,age) end
