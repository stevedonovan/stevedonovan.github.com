require_ 'forall1'

forall i in {10,20,30} do print(i) end

