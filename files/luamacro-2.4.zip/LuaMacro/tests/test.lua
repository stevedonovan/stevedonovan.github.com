print 'gotcha'
