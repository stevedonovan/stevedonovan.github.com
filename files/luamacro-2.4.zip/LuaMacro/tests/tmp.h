#ifndef TMP_H
#define TMP_H
typedef struct {
   int ival;
} MyStruct;

