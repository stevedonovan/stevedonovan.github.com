include_ 'test.inc'
print(answer)
