require 'str'
  assert (str.at("hello",2) == "e")
  assert (str.upto("123 567 9") == 4)
