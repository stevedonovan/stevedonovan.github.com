--- mymod

local mymod = {}

--- everything!
function mymod.query (
    a, --string: first arg
    b, --int: second arg
    c  --table: arg
)
end


--- for everything.
function mymod.answer (
    a, -- first arg
    b, -- second arg
    c)  -- third arg
end

return mymod
