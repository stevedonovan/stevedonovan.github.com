-------
-- A script.
-- Scripts are not containers in the sense that modules are,
-- (although perhaps the idea of 'commands' could be adopted for some utilities)
-- It allows any upfront script comments to be included in the
-- documentation.
-- @script modtest

print 'hello, world'
