---------------------
-- Another test module.
-- This one uses _Markdown_ formating, and
-- so can include goodies such as `code`
-- and lists:
--
--  - one
--  - two
--  - three
--
-- @module mod2

--- really basic function. Can contain links such as
-- [this](http://lua-users.org/wiki/FindPage)
-- @param first like `gsb(x)`
-- @param second **bold** maybe? It can continue:
--
--  - another point
--  - finish the damn list
-- @param third as before
function mod2.basic(first,second,third)

end


