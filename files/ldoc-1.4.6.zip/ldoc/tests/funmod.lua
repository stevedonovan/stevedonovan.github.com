-------
-- Summing values.
-- Returns a single function.
-- @param a first
-- @param b second
-- @param c third
-- @return sum of parameters
-- @module funmod

return function(a,b,c)
   return a + b + c
end

