require 'pl'
print(stringx.expandtabs('1\t22\t33\n1\t22\t333',4))

