print '1\t22\t33\n1\t22\t333'.expandtabs(4)
