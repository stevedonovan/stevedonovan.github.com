The docgen.lua script generates the HTML documentation from penlight.md,
using a custom version of markdown.lua which does ToC generation.

This script also finds @see references and resolves them.

The API documentation requires LuaDoc - run from api folder.



