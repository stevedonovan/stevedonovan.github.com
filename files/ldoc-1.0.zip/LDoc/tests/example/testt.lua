T = [[
here
# for i = 1,2 do
# swap (_put,i==2,
   hello!
# ,
   dolly!
# )
  and
# end
# for i = 1,2 do
  hello dolly!
# end
rest
]]

function swap(f,s,s1,s2)
  if s then f(s2); f(s1)
  else f(s1); f(s2)
  end
end

template = require 'pl.template'
print(template.substitute(T,_G))
