--[[--
Testing annotations and module usage

@usage
annot1.first()
annot1.second()

@module annot1
]]

--- first function.
-- @todo check if this works!
-- @usage first()
function annot1.first ()
    if boo then

    end
    --- @fixme what about else?
end
