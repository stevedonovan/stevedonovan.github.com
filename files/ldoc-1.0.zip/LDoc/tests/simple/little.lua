--- Test module
-- @alias M

--[===[ But it stops working when the blank line is removed! ]===]
--- Blah blah blah.
-- More blah
-- @function MyFunc4
-- @param x
local function M_MyFunc4(x)
  -- ...
end
M.MyFunc4 = M_MyFunc4

