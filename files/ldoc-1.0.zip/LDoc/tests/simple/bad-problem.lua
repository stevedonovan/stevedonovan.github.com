-- this module has a comment.
-- But it's not a doc comment!
-- @module problem

-------
-- multiple values for tag.
-- @name fred
-- @class function

--- A problem function.
-- @param p a parameter
-- !doofus dog
-- @see frodo
function problem.fun(p)
    return 42
end
