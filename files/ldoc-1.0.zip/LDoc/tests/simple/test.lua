--- Test module
-- @alias M

--[===[ this works ]===]
--- Blah blah blah.
-- More blah
-- @function MyFunc1
-- @param x
local MyFunc1( x )
end

--[===[ this works  (blank line after this comment) ]===]

--- Blah blah blah.
-- More blah
-- @function MyFunc2
-- @param x
local MyFunc2( x )
end


--[===[ This still works with "weird" func declarations ]===]

--- Blah blah blah.
-- More blah
-- @function MyFunc3
-- @param x
local function M_MyFunc3(x)
  -- ...
end
M.MyFunc3 = M_MyFunc3

--[===[ But it stops working when the blank line is removed! ]===]
--- Blah blah blah.
-- More blah
-- @function MyFunc4
-- @param x
local function M_MyFunc4(x)
  -- ...
end
M.MyFunc4 = M_MyFunc4

--[===[ It works again when the long comment
spans several lines
]===]
--- Blah blah blah.
-- More blah
-- @function MyFunc5
-- @param x
local function M_MyFunc5(x)
  -- ...
end
M.MyFunc5 = M_MyFunc5

