--------
-- Process some command-line options!
-- (Description as before)
-- @script script1

require 'pl'

--- @usage
local usage = [[
script1: prints out its own usage
--help  prints this help
--pretty tries to do better!
]]

print(usage)
